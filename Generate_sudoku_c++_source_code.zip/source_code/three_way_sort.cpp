#include <iostream>
#include <iomanip>
#include <string>
#include <algorithm>
#include "Grid2D.h"

using namespace std;

enum class SortOrder { ASC, DESC };

// Parse "asc" / "desc" string into enum (case-insensitive)
SortOrder parseOrder(const string& arg) {
    string lower = arg;
    transform(lower.begin(), lower.end(), lower.begin(), ::tolower);
    if (lower == "desc") return SortOrder::DESC;
    if (lower == "asc")  return SortOrder::ASC;
    cerr << "Invalid order '" << arg << "'. Defaulting to ASC.\n";
    return SortOrder::ASC;
}

// Print the 2D raw pointer table
void printTable(Grid2D& table, int rows, int cols, const string& label) {
    cout << "\n" << label << "\n";
    cout << string(cols * 6, '-') << "\n";
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++)
            cout << setw(6) << table(i,j);
        cout << "\n";
    }
    cout << string(cols * 6, '-') << "\n";
}

// Swap two rows (shallow pointer swap — O(1), no column-by-column copy)
void swapRows(Grid2D& table, int a, int b) {
    int* temp = table[a];
    table[a]  = table[b];
    table[b]  = temp;
}

// 3-Way Partition (Dutch National Flag) on raw 2D pointer table by first column
// cols is not needed here — row swap is just a pointer swap
void threeWayPartition(Grid2D& table, int low, int high, SortOrder order) {
    if (low >= high) return;

    int pivot = table(low + (high - low) / 2, 0); // pivot from first column

    int lt = low;   // left boundary
    int gt = high;  // right boundary
    int i  = low;   // current index

    while (i <= gt) {
        int key = table(i, 0);

        bool goLeft  = (order == SortOrder::ASC) ? (key < pivot) : (key > pivot);
        bool goRight = (order == SortOrder::ASC) ? (key > pivot) : (key < pivot);

        if (goLeft) {
            swapRows(table, i, lt);
            lt++;
            i++;
        } else if (goRight) {
            swapRows(table, i, gt);
            gt--;
            // don't increment i — recheck swapped row
        } else {
            i++; // key == pivot, already in place
        }
    }

    threeWayPartition(table, low,    lt - 1, order);
    threeWayPartition(table, gt + 1, high,   order);
}

// Allocate a 2D raw pointer table (rows x cols)
Grid2D allocTable(int rows, int cols) {
    Grid2D table = new int*[rows];
    for (int i = 0; i < rows; i++)
        table[i] = new int[cols];
    return table;
}

// Free a 2D raw pointer table
void freeTable(Grid2D& table, int rows) {
    for (int i = 0; i < rows; i++)
        delete[] table[i];
    delete[] table;

// Public sort entry point — cols not needed (pointer swap handles any width)
void sortTable(Grid2D& table, int rows, SortOrder order = SortOrder::ASC) {
    if (!table || rows <= 0) return;
    threeWayPartition(table, 0, rows - 1, order);
}

// Fill a table from a flat int array (row-major order)
void fillTable(Grid2D& table, int rows, int cols, int* src) {
    for (int i = 0; i < rows; i++)
        for (int j = 0; j < cols; j++)
            table(i,j) = src[i * cols + j];
}

int main(int argc, char* argv[]) {
    // Usage: ./three_way_sort [asc|desc]
    SortOrder order = SortOrder::ASC;
    if (argc >= 2) {
        order = parseOrder(argv[1]);
    } else {
        cout << "No order specified. Usage: ./three_way_sort [asc|desc]\n";
        cout << "Defaulting to ASC.\n";
    }

    // ----------------------------------------------------------------
    // Example 1: 3 columns
    // ----------------------------------------------------------------
    {
        const int ROWS = 12, COLS = 3;
        int src[] = {
            5, 21, 300,
            2, 45, 100,
            5, 33, 210,
            1, 78, 500,
            3, 12, 440,
            2, 67, 320,
            5, 90, 150,
            1, 55, 270,
            3, 44, 380,
            2, 11, 490,
            4, 88, 230,
            3, 29, 610,
        };

        Grid2D table = allocTable(ROWS, COLS);
        fillTable(table, ROWS, COLS, src);

        string label = "EXAMPLE 1 (" + to_string(COLS) + " cols) AFTER SORT - " +
                       string(order == SortOrder::ASC ? "ASC" : "DESC");

        printTable(table, ROWS, COLS, "EXAMPLE 1 (" + to_string(COLS) + " cols) BEFORE SORT");
        sortTable(table, ROWS, order);
        printTable(table, ROWS, COLS, label);

        freeTable(table, ROWS);
    }

    // ----------------------------------------------------------------
    // Example 2: 5 columns (variable — just change COLS and src)
    // ----------------------------------------------------------------
    {
        const int ROWS = 8, COLS = 5;
        int src[] = {
            4, 10, 20, 30, 40,
            1, 55, 65, 75, 85,
            4, 11, 22, 33, 44,
            2, 99, 88, 77, 66,
            3, 13, 26, 39, 52,
            2, 70, 60, 50, 40,
            3, 14, 28, 42, 56,
            1, 80, 70, 60, 50,
        };

        Grid2D table = allocTable(ROWS, COLS);
        fillTable(table, ROWS, COLS, src);

        string label = "EXAMPLE 2 (" + to_string(COLS) + " cols) AFTER SORT - " +
                       string(order == SortOrder::ASC ? "ASC" : "DESC");

        printTable(table, ROWS, COLS, "EXAMPLE 2 (" + to_string(COLS) + " cols) BEFORE SORT");
        sortTable(table, ROWS, order);
        printTable(table, ROWS, COLS, label);

        freeTable(table, ROWS);
    }

    return 0;
}
