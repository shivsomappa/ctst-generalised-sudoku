// =============================================================================
// Create_sudoku_M1.cpp
// Puzzle generation method M1.
//
// Fills puzzle_board (the clue grid visible to the solver) and solution_board
// (the complete, correct answer grid) using generation strategy 1:
//   M1 – starts from a cyclic template, shifts rows/columns within blocks,
//         then removes symbols to expose key cells.
//   M2 – similar to M1 but uses a different key-cell selection policy.
//   M3 – generates with minimum initial symbols; partially implements Sudoku
//         properties before key-cell creation.
//   M4 – completely random initial symbol placement.
//
// Internal nomenclature:
//   opt_tbl      (Grid3D) – options / candidate table, same layout as filters.h
//   puzzle_board (Grid2D) – clue cells; 0 = empty
//   solution_board(Grid2D)– complete solution
//   block_size            – square root of board dimension (e.g. 3 for 9x9)
// =============================================================================

#include "gsv.h"

using namespace std;
int m1_create_sudoku_template(Grid3D& opt_tbl, Grid2D& puzzle_board, Grid2D& solution_board, int size, int block_size);
int m1_randomise_sudoku_rc_shift(Grid2D& table, int size, int block_size);
int m1_row_shift_within_blk(Grid2D& table, int size, int bx, int block_size);
int m1_column_shift_within_blk(Grid2D& table, int size, int bx, int block_size);
int m1_select_least_count_block(Grid2D& puzzle_board, int& x, int& y, int size, int block_size);

int m1_build_Options_table(Grid2D& puzzle_board, Grid3D& opt_tbl, int size);
int m1_implement_sudoku_property(Grid3D& opt_tbl, Grid2D& puzzle_board, Grid2D& solution_board, int size, int block_size);
int m1_find_least_count_set_size(Grid3D& opt_tbl, Grid2D& puzzle_board, Grid2D& solution_board, int size, int& lss, int& set1_count, int& set2_count, int& set4_count);

int m1_create_two_symbol_set(Grid3D& opt_tbl, Grid2D& puzzle_board, Grid2D& solution_board, int size, int block_size, int lss);
int m1_create_three_symbol_set_step_1(Grid3D& opt_tbl, Grid2D& puzzle_board, Grid2D& solution_board, int size, int block_size);
int m1_create_three_symbol_set_step_2(Grid3D& opt_tbl, Grid2D& puzzle_board, Grid2D& solution_board, int size, int block_size);
int m1_create_three_symbol_set_step_3(Grid3D& opt_tbl, Grid2D& puzzle_board, Grid2D& solution_board, int size, int block_size);
int m1_create_three_symbol_set_fx1(Grid3D& opt_tbl, Grid2D& puzzle_board, Grid2D& solution_board, int s1, int s2, int x, int y, int size, int block_size);
int m1_create_three_symbol_set_fx2(Grid3D& opt_tbl, Grid2D& puzzle_board, Grid2D& solution_board, int s1, int x, int y, int size, int block_size);

int m1_remove_single_symbol_set(Grid3D& opt_tbl, Grid2D& puzzle_board, Grid2D& solution_board, int size, int block_size);
int m1_remove_two_symbol_set(Grid3D& opt_tbl, Grid2D& puzzle_board, Grid2D& solution_board, int size, int block_size);
int m1_remove_symbol_from_options_table(Grid3D& opt_tbl, int s, int x, int y, int size, int block_size);

int m1_check_nearest_neighbour_condition_hrz(Grid2D& table, int s, int x, int y1, int y2, int size, int block_size);
int m1_check_nearest_neighbour_condition_vrt(Grid2D& table, int s, int x, int y1, int y2, int size, int block_size);

int m1_select_second_symbol(Grid3D& opt_tbl, Grid2D& puzzle_board, Grid2D& solution_board, int s1, int& s2, int x, int y, int size, int block_size);
int m1_select_third_symbol(Grid3D& opt_tbl, Grid2D& solution_board, Grid2D& puzzle_board, int s1, int s2, int& s3, int x, int y, int size, int block_size);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int m1_GENERAT_SUDOKU_METHOD(Grid3D& opt_tbl,Grid2D& puzzle_board,Grid2D& solution_board,int size,int block_size)
{

	m1_create_sudoku_template(opt_tbl,puzzle_board,solution_board,size,block_size);
	m1_build_Options_table(puzzle_board,opt_tbl,size);
	cout<<"Sudoku board created implementing  sudoku properties "<<endl;
	m1_implement_sudoku_property(opt_tbl,puzzle_board,solution_board,size,block_size);

	return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int m1_create_sudoku_template(Grid3D& opt_tbl,Grid2D& puzzle_board,Grid2D& solution_board,int size,int block_size)
{
	int i=0,j=0,k=0,start=0,end=0,x,y;
	int count1=0,count2=size*size*10/100;
	int bx=0,by=0;

	for (i = 0; i < size; i++)
	{
		for (j = 0; j < size; j++) { puzzle_board(i,j) = 0; solution_board(i,j) = 0; }
	}

	int *temp=NULL;
	temp=new int[size+1];

	int *temp1=NULL;
	temp1=new int[size+1];

	
	for(i=0;i<size;i++){temp[i]=i+1;}
	for(i=0;i<size;i++)
	{
		for(j=i+1;j<size;j++)
		{
			if((rand()+1)%2==0){k=temp[i];temp[i]=temp[j];temp[j]=k;}
		}
	}
	//create sudoku -spiral shift method
	for(j=0;j<size;j++)
	{
		for(i=0;i<size;i++){solution_board(i,j)=temp[i];}
		if((j+1)%block_size==0)
		{
			start=1;i=0;
			while(start<size){temp1[start]=temp[i];start++;i++;}
			start=0;while(i<size){temp1[start]=temp[i];i++;start++;}
			
		}
		else
		{
			start=block_size;i=0;
			while(start<size){temp1[start]=temp[i];start++;i++;}
			start=0;while(i<size){temp1[start]=temp[i];i++;start++;}
		}
		for(i=0;i<size;i++){temp[i]=temp1[i];}
	}
	//rand0mise sudoku
	m1_randomise_sudoku_rc_shift(solution_board, size, block_size);
	//copy sudoku to solution_board
	for(i=0;i<size;i++)
	{
		for(j=0;j<size;j++){puzzle_board(i,j)=0;}
	}

	//add symbols randmly to  puzzal board
	srand(time(0));
	while(count1<count2)
	{
		x=rand()%block_size;
		y=rand()%block_size;
		m1_select_least_count_block(puzzle_board,  x,  y, size, block_size);
		if(puzzle_board(x,y)==0)
		{
			puzzle_board(x,y)=solution_board(x,y);
			count1++;
		}
		
	}

	delete[] temp;
	delete[] temp1;
	return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int m1_select_least_count_block(Grid2D& puzzle_board,int& x, int& y,int size,int block_size)
{
	int i, j, X = x, Y = y, count = block_size * block_size,bx,by,c;

	for (bx = 0; bx < size; bx=bx+block_size)
	{
		for (by = 0; by < size; by=by+block_size)
		{
			if (puzzle_board(bx+X,by+Y)==0)
			{
				c = 0;
				for (i = bx; i < bx + block_size; i++)
				{
					for (j = by; j < by + block_size; j++)
					{
						if (puzzle_board(i,j) > 0) { c++; }
					}
					
				}
				if (c < count) { count = c; x = bx + X; y = by + Y; }
			}
		}
	}
	
	return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int m1_randomise_sudoku_rc_shift(Grid2D& table,int size,int block_size)
{
	int i=0;
	for(i=0;i<size;i=i+block_size)
	{
		m1_row_shift_within_blk(table, size,i, block_size);
	}

	for(i=0;i<size;i=i+block_size)
	{
		m1_column_shift_within_blk(table, size,i, block_size);
	}

	return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int m1_row_shift_within_blk(Grid2D& table,int size,int bx,int block_size)
{
	int x,i,j,s;
	
	for(i=bx;i<bx+block_size;i++)
	{
		x=rand()%block_size+bx;
		if(x!=i)
		{
			for(j=0;j<size;j++){s=table(i,j);table(i,j)=table(x,j);table(x,j)=s;}
		}
	}
	return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int m1_column_shift_within_blk(Grid2D& table,int size,int by,int block_size)
{
	int y,i,j,s;

	for(j=by;j<by+block_size;j++)
	{
		y=rand()%block_size+by;
		if(y!=j)
		{
			for(i=0;i<size;i++){s=table(i,j);table(i,j)=table(i,y);table(i,y)=s;}
		}
	}
	return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int m1_implement_sudoku_property(Grid3D& opt_tbl,Grid2D& puzzle_board,Grid2D& solution_board,int size,int block_size)
{
	int flag=0,lss,set1_count=0,set2_count=0,set3_count=1;

	int t=0;
	//initialise process
	m1_find_least_count_set_size(opt_tbl,puzzle_board,solution_board,size,lss,set1_count,set2_count,set3_count);
	if(set2_count==0)

	while(set3_count>0)
	{
		
		if(set1_count>0)
		{
			m1_create_three_symbol_set_step_1(opt_tbl,puzzle_board,solution_board, size, block_size);
			m1_remove_single_symbol_set(opt_tbl,puzzle_board,solution_board, size, block_size);
		}
		else if(set2_count>0)
		{
			m1_create_three_symbol_set_step_2(opt_tbl,puzzle_board,solution_board, size, block_size);
			m1_create_three_symbol_set_step_3(opt_tbl, puzzle_board, solution_board, size, block_size);
			m1_remove_two_symbol_set(opt_tbl,puzzle_board,solution_board, size, block_size);
		}
		else 
		{
			m1_create_two_symbol_set(opt_tbl,puzzle_board,solution_board, size, block_size, lss);
			m1_create_three_symbol_set_step_2(opt_tbl, puzzle_board, solution_board, size, block_size);
			m1_create_three_symbol_set_step_3(opt_tbl, puzzle_board, solution_board, size, block_size);
			m1_remove_two_symbol_set(opt_tbl, puzzle_board, solution_board, size, block_size);
		}
		m1_find_least_count_set_size(opt_tbl, puzzle_board, solution_board, size, lss, set1_count, set2_count, set3_count);
	
	}

	return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int m1_create_three_symbol_set_step_2(Grid3D& opt_tbl, Grid2D& puzzle_board, Grid2D& solution_board, int size, int block_size)
{
	int i, j, s1, s2;
	int x, y, x1, y1;

	for (i = 0;i < size;i++)
	{
		for (j = 0;j < size;j++)
		{
			if (opt_tbl(i,j,0) == 2)
			{
				s1 = solution_board(i,j);
				s2 = 1;while (opt_tbl(i,j,s2) == 0 || opt_tbl(i,j,s2) == s1) { s2++; }

				x = 0; while (solution_board(x,j) != s2) { x++; }
				y = 0; while (solution_board(i,y) != s2) { y++; }

				y1 = 0;while (solution_board(x,y1) != s1) { y1++; }
				x1 = 0;while (solution_board(x1,y) != s1) { x1++; }

				if (puzzle_board(x,y1) == 0 && puzzle_board(x1,y) == 0)
				{
					if (x1 == x && y1 == y)
					{
						if (opt_tbl(x,j,0) > 3 && opt_tbl(i,y,0) > 3)
						{

							puzzle_board(x1,y1) = solution_board(x1,y1);
							m1_remove_symbol_from_options_table(opt_tbl, s1, x1, y1, size, block_size);
						}
						else if (opt_tbl(x,j,0) > 3 && opt_tbl(i,y,s2) == 0)
						{
							puzzle_board(x1,y1) = solution_board(x1,y1);
							m1_remove_symbol_from_options_table(opt_tbl, s1, x1, y1, size, block_size);
						}
						else if (opt_tbl(i,y,0) > 3 && opt_tbl(x,j,s1) == 0)
						{
							puzzle_board(x1,y1) = solution_board(x1,y1);
							m1_remove_symbol_from_options_table(opt_tbl, s1, x1, y1, size, block_size);
						}
					}
					else if (opt_tbl(i,y,0) < 4 && opt_tbl(i,y,s1)>0)
					{
						puzzle_board(x,y1) = solution_board(x,y1);
						m1_remove_symbol_from_options_table(opt_tbl, s1, x, y1, size, block_size);

					}
					else if (opt_tbl(x,j,0) < 4 && opt_tbl(x,j,s1)>0)
					{
						puzzle_board(x1,y) = solution_board(x1,y);
						m1_remove_symbol_from_options_table(opt_tbl, s1, x1, y, size, block_size);

					}
					else if (opt_tbl(x,j,0) < opt_tbl(i,y,0))
					{
						puzzle_board(x,y1) = solution_board(x,y1);
						m1_remove_symbol_from_options_table(opt_tbl, s1, x, y1, size, block_size);
					}
					else
					{
						puzzle_board(x1,y) = solution_board(x1,y);
						m1_remove_symbol_from_options_table(opt_tbl, s1, x1, y, size, block_size);
					}
				}

			}
		}
	}
	return 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int m1_create_two_symbol_set(Grid3D& opt_tbl, Grid2D& puzzle_board, Grid2D& solution_board, int size, int block_size, int lss)
{
	int i = 0, j, s1 = 0, s2 = 0, s3, flag = 0;
	int x, y, x1, y1;

	while (i < size && flag == 0)
	{
		j = 0;
		while (j < size && flag == 0)
		{
			if (opt_tbl(i,j,0) == lss)
			{
				s1 = solution_board(i,j);
				m1_select_second_symbol(opt_tbl, puzzle_board, solution_board, s1, s2, i, j, size, block_size);
				if (s2 > 0)
				{
					flag = 1;
					x = 0;y = 0;
					while (solution_board(x,j) != s2) { x++; }
					while (solution_board(i,y) != s2) { y++; }
					// first remove common option of s1 cell and s2 cell
					for (s3 = 1;s3 < size + 1;s3++)
					{
						if (s3 != s1 && s3 != s2 && opt_tbl(i,j,s3) > 0)
						{
							x1 = 0;y1 = 0;
							while (solution_board(x1,j) != s3) { x1++; }
							while (solution_board(i,y1) != s3) { y1++; }

							if (opt_tbl(x,j,s3) > 0 && opt_tbl(i,y,s3) > 0)
							{
								if (opt_tbl(i,y,0) < opt_tbl(x,j,0))
								{
									puzzle_board(i,y1) = solution_board(i,y1);
									m1_remove_symbol_from_options_table(opt_tbl, s3, i, y1, size, block_size);
								}
								else
								{
									puzzle_board(x1,j) = solution_board(x1,j);
									m1_remove_symbol_from_options_table(opt_tbl, s3, x1, j, size, block_size);
								}

							}
							else if (opt_tbl(x,j,s3) > 0)
							{
								puzzle_board(x1,j) = solution_board(x1,j);
								m1_remove_symbol_from_options_table(opt_tbl, s3, x1, j, size, block_size);
							}
							else if (opt_tbl(i,y,s3) > 0)
							{
								puzzle_board(i,y1) = solution_board(i,y1);
								m1_remove_symbol_from_options_table(opt_tbl, s3, i, y1, size, block_size);
							}
						}
					}
					// if set size greater than two
					if (opt_tbl(i,j,0) > 2)
					{
						for (s3 = 1;s3 < size + 1;s3++)
						{
							if (s3 != s1 && s3 != s2 && opt_tbl(i,j,s3) > 0)
							{
								x1 = 0;y1 = 0;
								while (solution_board(x1,j) != s3) { x1++; }
								while (solution_board(i,y1) != s3) { y1++; }

								if (opt_tbl(x1,j,0) > opt_tbl(i,y1,0))
								{
									puzzle_board(x1,j) = solution_board(x1,j);
									m1_remove_symbol_from_options_table(opt_tbl, s3, x1, j, size, block_size);
								}
								else
								{
									puzzle_board(i,y1) = solution_board(i,y1);
									m1_remove_symbol_from_options_table(opt_tbl, s3, i, y1, size, block_size);

								}
							}
						}
					}
				}
			}
			j++;
		}
		i++;
	}
	return 0;

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int m1_create_three_symbol_set_step_1(Grid3D& opt_tbl, Grid2D& puzzle_board, Grid2D& solution_board, int size, int block_size)
{
	int i, j, k, set22 = 0, set13 = 0, set23 = 0, s1, f;


	for (i = 0; i < size; i++)
	{
		for (j = 0; j < size; j++)
		{
			if (opt_tbl(i,j,0) == 1)
			{
				s1 = solution_board(i,j); f = 0;
				for (k = 0; k < size; k++)
				{
					if (opt_tbl(k,j,0) == 2 && opt_tbl(k,j,s1) > 0) { f = 1; }
					if (opt_tbl(i,k,0) == 2 && opt_tbl(i,k,s1) > 0) { f = 1; }
				}

				if (f == 0)
				{
					m1_create_three_symbol_set_fx2(opt_tbl, puzzle_board, solution_board, s1, i, j, size, block_size);
				}
			}
		}
	}
	return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int m1_create_three_symbol_set_step_3(Grid3D& opt_tbl, Grid2D& puzzle_board, Grid2D& solution_board, int size, int block_size)
{
	int i, j, s1, s2, flag = 0;

	for (i = 0; i < size; i++)
	{
		for (j = 0; j < size; j++)
		{
			if (opt_tbl(i,j,0) == 2)
			{
				s1 = solution_board(i,j);
				s2 = 1; while (opt_tbl(i,j,s2) == 0 || opt_tbl(i,j,s2) == s1) { s2++; }
				opt_tbl(i,j,size + 2) = -1;

				flag = m1_create_three_symbol_set_fx1(opt_tbl, puzzle_board, solution_board, s1, s2, i, j, size, block_size);
				if (flag == 0)
				{
					m1_create_three_symbol_set_fx2(opt_tbl, puzzle_board, solution_board, s1, i, j, size, block_size);
				}
			}
		}
	}
	return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int m1_create_three_symbol_set_fx1(Grid3D& opt_tbl, Grid2D& puzzle_board, Grid2D& solution_board, int s1, int s2, int x, int y, int size, int block_size)
{
	int  s3 = 0, s4 = 0, j,  flag = 0;
	int x1, y1, x2, y2;

	x1 = 0; while (solution_board(x1,y) != s2) { x1++; }
	y1 = 0; while (solution_board(x,y1) != s2) { y1++; }

	if (opt_tbl(x,y1,0) > 3 && opt_tbl(x1,y,0) > 3)
	{
		if (opt_tbl(x1,y,s1) > 0 && opt_tbl(x,y1,s1) == 0) { y1 = y; }
		else if (opt_tbl(x1,y,s1) == 0 && opt_tbl(x,y1,s1) > 0) { x1 = x; }
		else if (opt_tbl(x1,y,0) < opt_tbl(x,y1,0)) { y1 = y; }
		else { x1 = x; }

		if (opt_tbl(x1,y1,s1) > 0)
		{
			s3 = s1;
			flag = 1;
			m1_select_third_symbol(opt_tbl, solution_board, puzzle_board, s2, s3, s4, x1, y1, size, block_size);
		}
		else
		{
			m1_select_second_symbol(opt_tbl, solution_board, puzzle_board, s2, s3, x1, y1, size, block_size);
			m1_select_third_symbol(opt_tbl, solution_board, puzzle_board, s2, s3, s4, x1, y1, size, block_size);
		}

		//*******************************************************************
		if (s3 > 0 && s4 > 0)
		{

			for (j = 1; j < size + 1; j++)
			{
				if (opt_tbl(x1,y1,j) > 0 && j != s2 && j != s3 && j != s4)
				{
					x2 = 0;y2 = 0;
					while (solution_board(x2,y1) != j) { x2++; }
					while (solution_board(x1,y2) != j) { y2++; }

					if (opt_tbl(x1,y2,0) > opt_tbl(x2,y1,0))
					{
						puzzle_board(x1,y2) = solution_board(x1,y2);
						m1_remove_symbol_from_options_table(opt_tbl, j, x1, y2, size, block_size);
					}
					else
					{
						puzzle_board(x2,y1) = solution_board(x2,y1);
						m1_remove_symbol_from_options_table(opt_tbl, j, x2, y1, size, block_size);
					}
				}
			}
		}
	}
	else if (opt_tbl(x1,y,0) < 4 && opt_tbl(x1,y,s1)>0) { flag = 1; }
	else if (opt_tbl(x,y1,0) < 4 && opt_tbl(x,y1,s1)>0) { flag = 1; }

	return flag;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int m1_create_three_symbol_set_fx2(Grid3D& opt_tbl, Grid2D& puzzle_board, Grid2D& solution_board, int s1, int x, int y, int size, int block_size)
{
	int i, j, k, c = size + 1, f1, f2;
	int x1 = -1, y1 = -1, x2, y2;
	int s2 = 0, s3 = 0;
	for (i = 0; i < size; i++)
	{
		if (i != y && opt_tbl(x,i,s1) > 0)
		{
			k = solution_board(x,i);
			if (m1_check_nearest_neighbour_condition_hrz(puzzle_board, k, x, y, i, size, block_size) == 0)
			{
				if (opt_tbl(x,i,0) < c) { c = opt_tbl(x,i,0); x1 = x; y1 = i; s2 = k; }
			}
		}
		if (i != x && opt_tbl(i,y,s1) > 0)
		{
			k = solution_board(i,y);
			if (m1_check_nearest_neighbour_condition_vrt(puzzle_board, k, x, i, y, size, block_size) == 0)
			{
				if (opt_tbl(i,y,0) < c) { c = opt_tbl(i,y,0); x1 = i; y1 = y; s2 = k; }
			}
		}
	}

	//***********************************************
	if (x1 > -1 && c > 3)
	{
		c = size + 1;
		for (k = 1; k < size + 1; k++)
		{
			if (opt_tbl(x1,y1,k) > 0 && k != s1 && k != s2)
			{
				i = 0; while (solution_board(i,y1) != k) { i++; }
				j = 0; while (solution_board(x1,j) != k) { j++; }

				f1 = m1_check_nearest_neighbour_condition_vrt(puzzle_board, k, x1, i, y1, size, block_size);
				f2 = m1_check_nearest_neighbour_condition_hrz(puzzle_board, k, x1, j, y1, size, block_size);

				if (f1 == 0 && f2 == 0)
				{
					if (opt_tbl(x1,j,0) < opt_tbl(i,y1,0)) { c = opt_tbl(x1,j,0); s3 = k; }
					else { c = opt_tbl(i,y1,0); s3 = k; }
				}
				else if (f1 == 0) { c = opt_tbl(i,y1,0); s3 = k; }
				else if (f2 == 0) { c = opt_tbl(x1,j,0); s3 = k; }
			}
		}
		if (s3 > 0)
		{
			for (j = 1; j < size + 1; j++)
			{
				if (opt_tbl(x1,y1,j) > 0 && j != s1 && j != s2 && j != s3)
				{
					x2 = 0;y2 = 0;
					while (solution_board(x2,y1) != j) { x2++; }
					while (solution_board(x1,y2) != j) { y2++; }

					if (opt_tbl(x1,y2,0) > opt_tbl(x2,y1,0))
					{
						puzzle_board(x1,y2) = solution_board(x1,y2);
						m1_remove_symbol_from_options_table(opt_tbl, j, x1, y2, size, block_size);
					}
					else
					{
						puzzle_board(x2,y1) = solution_board(x2,y1);
						m1_remove_symbol_from_options_table(opt_tbl, j, x2, y1, size, block_size);
					}
				}
			}
		}
	}
	return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int m1_build_Options_table(Grid2D& puzzle_board, Grid3D& opt_tbl, int size)
{
	int i = 0, j = 0, k = 0, l = 0, s = 0, bx = 0, by = 0, bl = int(sqrt(size));
	//initalise
	for (i = 0; i < size; i++)
	{
		for (j = 0; j < size; j++)
		{
			for (k = 0; k < size + 1; k++)
			{
				if (puzzle_board(i,j) == 0) { opt_tbl(i,j,k) = k; opt_tbl(i,j,0) = size; }
				else { opt_tbl(i,j,k) = 0; }
			}
			opt_tbl(i,j,size + 1) = 0;
			opt_tbl(i,j,size + 2) = 0;
		}
	}
	//***********************************************
	for (i = 0; i < size; i++)
	{
		for (j = 0; j < size; j++)
		{
			//horizotal maping
			for (k = 0; k < size; k++)
			{
				s = puzzle_board(i,k);
				if (s > 0 && opt_tbl(i,j,0) > 0)
				{
					opt_tbl(i,j,s) = 0; opt_tbl(i,j,0)--;
				}
			}
			//verticle maping
			for (k = 0; k < size; k++)
			{
				s = puzzle_board(k,j);
				if (s > 0 && opt_tbl(i,j,s) > 0 && opt_tbl(i,j,0) > 0)
				{
					opt_tbl(i,j,s) = 0; opt_tbl(i,j,0)--;
				}
			}
			//block maping
			bx = (i / bl) * bl; by = (j / bl) * bl;
			for (k = bx; k < bx + bl; k++)
			{
				for (l = by; l < by + bl; l++)
				{
					s = puzzle_board(k,l);
					if (s > 0 && opt_tbl(i,j,s) > 0 && opt_tbl(i,j,0) > 0)
					{
						opt_tbl(i,j,s) = 0; opt_tbl(i,j,0)--;
					}
				}
			}
		}
	}
	return 0;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int m1_remove_single_symbol_set(Grid3D& opt_tbl, Grid2D& puzzle_board, Grid2D& solution_board, int size, int block_size)
{
	int i = 0, j = 0, k = 0, s1, flag = 1;

	while (flag == 1)
	{
		flag = 0;
		for (i = 0; i < size; i++)
		{
			for (j = 0; j < size; j++)
			{
				if (opt_tbl(i,j,0) == 1)
				{
					flag = 1; s1 = solution_board(i,j);
					m1_remove_symbol_from_options_table(opt_tbl, s1, i, j, size, block_size);
				}
			}
		}
	}

	return flag;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int m1_remove_two_symbol_set(Grid3D& opt_tbl, Grid2D& puzzle_board, Grid2D& solution_board, int size, int block_size)
{
	int i = 0, j = 0, k = 0, s;

	for (i = 0; i < size; i++)
	{
		for (j = 0; j < size; j++)
		{
			if (opt_tbl(i,j,0) == 2 && opt_tbl(i,j,size + 2) == -1)
			{
				s = solution_board(i,j);
				for (k = 0; k < size + 1; k++) { opt_tbl(i,j,k) = 0; }
				m1_remove_symbol_from_options_table(opt_tbl, s, i, j, size, block_size);
			}
		}
	}
	return 0;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int m1_remove_symbol_from_options_table(Grid3D& opt_tbl, int s, int x, int y, int size, int block_size)
{
	int i, j;
	int bx = (x / block_size) * block_size, by = (y / block_size) * block_size;
	//hrz
	for (i = 0; i < size; i++)
	{
		if (opt_tbl(x,i,s) > 0)
		{
			opt_tbl(x,i,s) = 0; opt_tbl(x,i,0)--;
		}
	}

	//vrt
	for (i = 0; i < size; i++)
	{

		if (opt_tbl(i,y,s) > 0)
		{
			opt_tbl(i,y,s) = 0; opt_tbl(i,y,0)--;
		}
	}
	//block
	for (i = bx; i < bx + block_size; i++)
	{
		for (j = by; j < by + block_size; j++)
		{
			if (opt_tbl(i,j,s) > 0)
			{
				opt_tbl(i,j,s) = 0; opt_tbl(i,j,0)--;

			}
		}
	}
	for (i = 0; i < size + 1; i++) { opt_tbl(x,y,i) = 0; }
	return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int m1_find_least_count_set_size(Grid3D& opt_tbl, Grid2D& puzzle_board, Grid2D& solution_board, int size, int& lss, int& set1_count, int& set2_count, int& set3_count)
{
	int i, j, c = 0, c1 = 0;

	set1_count = 0; lss = size; set2_count = 0; set3_count = 0;

	for (i = 0; i < size; i++)
	{
		for (j = 0; j < size; j++)
		{
			if (opt_tbl(i,j,0) > 0)
			{
				if (opt_tbl(i,j,0) == 1) { set1_count++; }
				else if (opt_tbl(i,j,0) == 2) { set2_count++; }
				else { c1++; }

				if (opt_tbl(i,j,0) != c) { c = opt_tbl(i,j,0); set3_count++; }
				if (opt_tbl(i,j,0) < lss) { lss = opt_tbl(i,j,0); }
			}
		}
	}
	cout << "Number of sets to be removed from options table " << c1 << "\r";
	cout.flush();

	if (set3_count == 1)
	{
		for (i = 0; i < size; i++)
		{
			for (j = 0; j < size; j++)
			{
				if (opt_tbl(i,j,0) > 0)
				{
					puzzle_board(i,j) = solution_board(i,j);
					opt_tbl(i,j,0) = 0;
				}
			}
		}
		set3_count = 0;
	}
	return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int m1_check_nearest_neighbour_condition_hrz(Grid2D& table, int s, int x, int y1, int y2, int size, int block_size)
{
	int i, j, k, f = 0;
	int bx = (x / block_size) * block_size;
	int by1 = (y1 / block_size) * block_size, by2 = (y2 / block_size) * block_size;


	if (by1 < by2 && by2 - by1 > block_size)
	{
		for (k = by1; k < by2; k = k + block_size)
		{
			for (i = bx; i < bx + block_size; i++)
			{
				for (j = k; j < k + block_size; j++) { if (table(i,j) == s) { f = 1; } }
			}
		}
	}
	else if (by2 < by1 && by1 - by2 > block_size)
	{
		for (k = by2; k < by1; k = k + block_size)
		{
			for (i = bx; i < bx + block_size; i++)
			{
				for (j = k; j < k + block_size; j++) { if (table(i,j) == s) { f = 1; } }
			}
		}

	}
	return f;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int m1_check_nearest_neighbour_condition_vrt(Grid2D& table, int s, int x1, int x2, int y, int size, int block_size)
{
	int i, j, k, f = 0;
	int by = (y / block_size) * block_size;
	int bx1 = (x1 / block_size) * block_size, bx2 = (x2 / block_size) * block_size;

	if (bx1 < bx2 && bx2 - bx1 > block_size)
	{
		for (k = bx1; k < bx2; k = k + block_size)
		{
			for (i = k; i < k + block_size; i++)
			{
				for (j = by; j < by + block_size; j++) { if (table(i,j) == s) { f = 1; } }
			}
		}
	}
	else if (bx2 < bx1 && bx1 - bx2 > block_size)
	{
		for (k = bx2; k < bx1; k = k + block_size)
		{
			for (i = k; i < k + block_size; i++)
			{
				for (j = by; j < by + block_size; j++) { if (table(i,j) == s) { f = 1; } }
			}
		}
	}
	return f;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int m1_select_second_symbol(Grid3D& opt_tbl, Grid2D& puzzle_board, Grid2D& solution_board, int s1, int& s2, int x, int y, int size, int block_size)
{
	int i = 0, k, c = size + 1, f;

	s2 = 0;
	for (k = 1; k < size + 1; k++)
	{
		if (opt_tbl(x,y,k) > 0 && k != s1)
		{
			for (i = 0; i < size; i++)
			{
				if (solution_board(i,y) == k && opt_tbl(i,y,0) < c && opt_tbl(i,y,0)>opt_tbl(x,y,0))
				{
					f = m1_check_nearest_neighbour_condition_vrt(solution_board, k, i, x, y, size, block_size);
					if (f == 0) { s2 = k; c = opt_tbl(i,y,0); }
				}

				if (solution_board(x,i) == k && opt_tbl(x,i,0) < c)
				{
					f = m1_check_nearest_neighbour_condition_hrz(puzzle_board, k, x, i, y, size, block_size);
					if (f == 0) { s2 = k; c = opt_tbl(x,i,0); }
				}
			}
		}
	}
	return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int m1_select_third_symbol(Grid3D& opt_tbl, Grid2D& solution_board, Grid2D& puzzle_board, int s1, int s2, int& s3, int x, int y, int size, int block_size)
{
	int i, j, k, c = size + 1, f1, f2;

	s3 = 0;
	for (k = 1; k < size + 1; k++)
	{
		if (k != s1 && k != s2 && opt_tbl(x,y,k) > 0)
		{
			i = 0; while (solution_board(i,y) != k) { i++; }
			j = 0; while (solution_board(x,j) != k) { j++; }

			f1 = m1_check_nearest_neighbour_condition_vrt(puzzle_board, k, x, i, y, size, block_size);
			f2 = m1_check_nearest_neighbour_condition_hrz(puzzle_board, k, x, j, y, size, block_size);

			if (f1 == 0 && f2 == 0)
			{
				if (opt_tbl(x,j,0) < c) { c = opt_tbl(x,j,0); s3 = k; }
				if (opt_tbl(i,y,0) < c) { c = opt_tbl(i,y,0); s3 = k; }
			}
			else if (f1 == 0 && opt_tbl(i,y,0) < c) { c = opt_tbl(i,y,0); s3 = k; }
			else if (f2 == 0 && opt_tbl(x,j,0) < c) { c = opt_tbl(x,j,0); s3 = k; }
		}
	}

	return 0;
}
